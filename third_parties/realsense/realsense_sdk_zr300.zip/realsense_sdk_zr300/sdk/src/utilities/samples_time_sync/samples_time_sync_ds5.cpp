// License: Apache 2.0. See LICENSE file in root directory.
// Copyright(c) 2016 Intel Corporation. All Rights Reserved.

#include "samples_time_sync_ds5.h"

using namespace std;
using namespace rs::core;
using namespace rs::utils;

bool rs::utils::samples_time_sync_ds5::sync_all(streams_map& streams, motions_map& motions, rs::core::correlated_sample_set& sample_set )
{
    return false;
}
